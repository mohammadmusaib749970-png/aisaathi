package com.example.saathi

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.view.Display
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class AgentService : AccessibilityService() {

    companion object { @Volatile var inst: AgentService? = null }

    private val exec = Executors.newSingleThreadExecutor()
    private var tts: TextToSpeech? = null
    @Volatile var running = false

    override fun onServiceConnected() {
        inst = this
        tts = TextToSpeech(this) { tts?.language = Locale("hi", "IN") }
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { inst = null; super.onDestroy() }

    // वॉल्यूम-डाउन दबाओ तो AI रुक जाएगा
    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (running && e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && e.action == KeyEvent.ACTION_DOWN) {
            running = false; say("रुक गया"); return true
        }
        return false
    }

    fun say(t: String) { tts?.speak(t, TextToSpeech.QUEUE_ADD, null, null) }

    fun start(task: String, key: String) {
        if (running) return
        running = true
        Thread {
            try { loop(task, key) }
            catch (e: Exception) { say("गड़बड़ हो गई: " + (e.message ?: "").take(80)) }
            finally { running = false }
        }.start()
    }

    private fun loop(task: String, key: String) {
        val log = StringBuilder()
        for (step in 1..25) {
            if (!running) return
            Thread.sleep(1000)
            val b = shot() ?: run { say("स्क्रीन नहीं दिखी"); return }
            val sc = if (b.width > 720) 720f / b.width else 1f
            val sb = Bitmap.createScaledBitmap(b, (b.width * sc).toInt(), (b.height * sc).toInt(), true)
            val bo = ByteArrayOutputStream()
            sb.compress(Bitmap.CompressFormat.JPEG, 70, bo)
            val img = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
            val tool = ask(key, task, log.toString(), img, sb.width, sb.height) ?: run { say("समझ नहीं आया"); return }
            val name = tool.getString("name")
            val a = tool.getJSONObject("input")
            val s = a.optString("say")
            if (s.isNotEmpty()) say(s)
            log.append(step).append(". ").append(name).append(' ').append(a.toString()).append('\n')
            when (name) {
                "tap" -> swipe(a.getDouble("x") / sc, a.getDouble("y") / sc, a.getDouble("x") / sc + 1, a.getDouble("y") / sc, 60)
                "swipe" -> swipe(a.getDouble("x1") / sc, a.getDouble("y1") / sc, a.getDouble("x2") / sc, a.getDouble("y2") / sc, 350)
                "type_text" -> typeText(a.getString("text"))
                "open_app" -> openApp(a.getString("name"))
                "press" -> when (a.getString("button")) {
                    "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                    "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                    else -> performGlobalAction(GLOBAL_ACTION_RECENTS)
                }
                "wait" -> Thread.sleep(2000)
                "finish" -> return
            }
        }
        say("काफ़ी स्टेप हो गए, मैं रुक रहा हूँ")
    }

    private fun shot(): Bitmap? {
        val latch = CountDownLatch(1)
        var bmp: Bitmap? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, exec, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                r.hardwareBuffer.close()
                latch.countDown()
            }
            override fun onFailure(code: Int) { latch.countDown() }
        })
        latch.await(5, TimeUnit.SECONDS)
        return bmp
    }

    private fun swipe(x1: Double, y1: Double, x2: Double, y2: Double, dur: Long) {
        val p = Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        val l = CountDownLatch(1)
        dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { l.countDown() }
            override fun onCancelled(d: GestureDescription?) { l.countDown() }
        }, null)
        l.await(3, TimeUnit.SECONDS)
    }

    private fun typeText(t: String) {
        val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val old = if (n.isShowingHintText) "" else (n.text?.toString() ?: "")
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + t)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(i, 0)
        val q = name.lowercase()
        val m = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: apps.firstOrNull { q.contains(it.loadLabel(pm).toString().lowercase()) }
        if (m == null) { say("$name ऐप नहीं मिला"); return }
        val li = pm.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(li)
    }

    private fun tool(n: String, d: String, props: String, req: String) =
        JSONObject("""{"name":"$n","description":"$d","input_schema":{"type":"object","properties":{"say":{"type":"string","description":"हिंदी में एक छोटा वाक्य: अभी क्या कर रहे हो और क्यों"},$props},"required":[$req,"say"]}}""")

    private fun ask(key: String, task: String, log: String, img: String, w: Int, h: Int): JSONObject? {
        val num = """{"type":"number"}"""
        val tools = JSONArray().apply {
            put(tool("tap", "स्क्रीन पर एक जगह टैप करो", """"x":$num,"y":$num""", """"x","y""""))
            put(tool("swipe", "स्वाइप या स्क्रॉल करो", """"x1":$num,"y1":$num,"x2":$num,"y2":$num""", """"x1","y1","x2","y2""""))
            put(tool("type_text", "चुने हुए टेक्स्ट बॉक्स में टाइप करो (पहले उस पर टैप करो)", """"text":{"type":"string"}""", """"text""""))
            put(tool("open_app", "नाम से ऐप खोलो", """"name":{"type":"string"}""", """"name""""))
            put(tool("press", "सिस्टम बटन दबाओ", """"button":{"type":"string","enum":["back","home","recents"]}""", """"button""""))
            put(tool("wait", "स्क्रीन लोड होने का इंतज़ार करो", "", ""))
            put(tool("finish", "काम पूरा हो गया या आगे नहीं बढ़ सकते", "", ""))
        }
        val sys = "तुम 'AI साथी' हो: एक हिंदी बोलने वाला असिस्टेंट जो एंड्रॉइड फ़ोन की स्क्रीन देखकर यूज़र का काम खुद करता है। " +
            "हर बार स्क्रीनशॉट देखो और ठीक एक टूल चलाओ। निर्देशांक स्क्रीनशॉट के पिक्सल में दो। हर टूल में 'say' में हिंदी में छोटा सा बताओ कि क्या कर रहे हो। " +
            "टाइप करने से पहले टेक्स्ट बॉक्स पर टैप करो। काम पूरा होते ही finish चलाओ और say में नतीजा बताओ। " +
            "पासवर्ड, OTP, पेमेंट या पैसे भेजने जैसे संवेदनशील स्टेप खुद मत करो: finish चलाकर यूज़र से खुद करने को कहो। अटक जाओ तो finish चलाकर वजह बताओ।"
        val content = JSONArray()
            .put(JSONObject().put("type", "image").put("source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", img)))
            .put(JSONObject().put("type", "text").put("text", "काम: $task\nअब तक के स्टेप:\n${if (log.isEmpty()) "(अभी कुछ नहीं)" else log}\nस्क्रीन का साइज़: ${w}x$h पिक्सल।"))
        val body = JSONObject()
            .put("model", "claude-sonnet-5-5").put("max_tokens", 600).put("system", sys)
            .put("tools", tools).put("tool_choice", JSONObject().put("type", "any"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val txt = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (c.responseCode >= 400) throw Exception("API ${c.responseCode}: $txt")
        val arr = JSONObject(txt).getJSONArray("content")
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).getString("type") == "tool_use") return arr.getJSONObject(i)
        return null
    }
}
