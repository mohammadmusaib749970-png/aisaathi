package com.example.saathi

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var keyBox: EditText
    private lateinit var taskBox: EditText

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (t != null) { taskBox.setText(t); go() }
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val p = getSharedPreferences("p", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun tv(t: String, sz: Float) = TextView(this).apply { text = t; textSize = sz; setPadding(0, 16, 0, 16) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        root.addView(tv("🤖 AI साथी", 28f))
        root.addView(tv("1) नीचे Anthropic API key डालो  2) एक बार ऐक्सेसिबिलिटी चालू करो  3) बोलो या लिखो।\nरोकने के लिए वॉल्यूम-डाउन दबाओ।", 14f))
        keyBox = EditText(this).apply {
            hint = "API key (sk-ant-...)"; setText(p.getString("k", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        taskBox = EditText(this).apply { hint = "जैसे: WhatsApp खोलो और माँ को हाय भेजो" }
        root.addView(keyBox); root.addView(taskBox)
        root.addView(btn("🎤 बोलकर काम बताओ") {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            try { voice.launch(i) } catch (e: Exception) { toast("आवाज़ पहचान उपलब्ध नहीं, लिखकर भेजो") }
        })
        root.addView(btn("▶ काम शुरू करो") { go() })
        root.addView(btn("⚙ ऐक्सेसिबिलिटी चालू करो") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("⏹ रोको") { AgentService.inst?.running = false })
        setContentView(root)
    }

    private fun go() {
        val key = keyBox.text.toString().trim()
        val task = taskBox.text.toString().trim()
        if (key.isEmpty() || task.isEmpty()) { toast("API key और काम दोनों भरो"); return }
        getSharedPreferences("p", MODE_PRIVATE).edit().putString("k", key).apply()
        val svc = AgentService.inst
        if (svc == null) {
            toast("पहले ऐक्सेसिबिलिटी में 'AI साथी' चालू करो")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
        }
        svc.start(task, key)
        moveTaskToBack(true)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
}
